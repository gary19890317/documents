package com.walmart.example.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.example.producer.QueueProducer;

@RestController
public class JmsRestController {

	@Autowired
	private QueueProducer producer;

	@GetMapping("send")
	public String send() {
		try {
			producer.send("Hola Mundo!! " + UUID.randomUUID());
			return "OK";
		} catch (Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
	}
}
