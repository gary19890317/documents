package com.walmart.example.config;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.mq.spring.boot.MQConfigurationProperties;
import com.ibm.mq.spring.boot.MQConnectionFactoryCustomizer;
import com.ibm.mq.spring.boot.MQConnectionFactoryFactory;
import com.walmart.example.listener.QueueConsumer;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListenerConfigurer;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerEndpointRegistrar;
import org.springframework.jms.config.SimpleJmsListenerEndpoint;

import javax.jms.JMSException;
import java.util.List;
import java.util.UUID;

@Configuration
@EnableJms
public class JmsConfig implements JmsListenerConfigurer {

	@Autowired
	private Environment environment;

	@Autowired
	private ObjectProvider<List<MQConnectionFactoryCustomizer>> factoryCustomizers;

	@Autowired
	private DefaultJmsListenerContainerFactoryConfigurer configurer;

	@Autowired
	private QmProperties qmProperties;

	@Autowired
	private QueueConsumer queueConsumer;

	@Value("${jms.queueName}")
	private String queueName;

	@Override
	public void configureJmsListeners(JmsListenerEndpointRegistrar registrar) {
		for (MQConfigurationProperties properties : qmProperties.getList()) {
			String queueManager = properties.getQueueManager();
			
			System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", Boolean.FALSE.toString());
			properties.setSslFIPSRequired(Boolean.getBoolean(environment.getProperty("jms.sslFipsRequired")));
			properties.setSslCipherSuite(environment.getProperty("jms.sslCipherSuite"));

			MQConnectionFactory connectionFactory = new MQConnectionFactoryFactory(properties,
					factoryCustomizers.getIfAvailable()).createConnectionFactory(MQConnectionFactory.class);

			DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
			configurer.configure(factory, connectionFactory);

			SimpleJmsListenerEndpoint endpoint = new SimpleJmsListenerEndpoint();
			endpoint.setId("jmsEndpoint-" + queueManager + "-Id [" + UUID.randomUUID() + "]");
			endpoint.setDestination(queueName);
			endpoint.setMessageListener(message -> {
				try {
					queueConsumer.receive(endpoint.getId(), message.getBody(String.class));
				} catch (JMSException e) {
					throw new RuntimeException(e);
				}
			});
			registrar.registerEndpoint(endpoint, factory);
		}
	}

}