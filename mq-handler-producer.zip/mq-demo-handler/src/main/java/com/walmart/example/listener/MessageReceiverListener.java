package com.walmart.example.listener;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiverListener {

	@JmsListener(destination = "${jms.queueName}")
	public void receiveMessage(String msg) {
		System.out.println();
		System.out.println("========================================");
		System.out.println("Received message is: " + msg);
		System.out.println("========================================");

	}
}
