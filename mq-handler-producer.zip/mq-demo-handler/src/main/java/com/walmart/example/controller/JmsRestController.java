package com.walmart.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JmsRestController {

	@Autowired
	private JmsTemplate jmsTemplate;
	private String queuName = "DEV.QUEUE.1";
	
	@GetMapping("send")
	public String send() {
		try {
			jmsTemplate.convertAndSend(queuName, "Hola Mundo!");
			return "OK";
		} catch (Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
	}
	
	@GetMapping("recv")
	public String recv() {
		try {
			return jmsTemplate.receiveAndConvert(queuName).toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
	}
}
