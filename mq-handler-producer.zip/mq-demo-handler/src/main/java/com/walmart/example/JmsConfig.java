package com.walmart.example;

import javax.jms.ConnectionFactory;

import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;

import com.ibm.mq.spring.boot.MQConfigurationProperties;

@Configuration
@EnableJms
public class JmsConfig {
	private Environment environment;

	public JmsConfig(Environment environment) {
		this.environment = environment;
	}

	@Primary
	@Bean
	public MQConfigurationProperties mqConfigurationProperties() {
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", Boolean.FALSE.toString());
		MQConfigurationProperties config = new MQConfigurationProperties();
		config.setQueueManager(environment.getProperty("ibm.mq.queueManager"));
		config.setChannel(environment.getProperty("ibm.mq.channel"));
		config.setConnName(environment.getProperty("ibm.mq.connName"));
		config.setSslFIPSRequired(Boolean.getBoolean(environment.getProperty("ibm.mq.sslFipsRequired")));
		config.setSslCipherSuite(environment.getProperty("ibm.mq.sslCipherSuite"));
		return config;
	}

	@Bean
	public JmsListenerContainerFactory<?> jmsListenerContainerFactory(ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		configurer.configure(factory, connectionFactory);
		return factory;
	}

	@Bean
	public MessageConverter jacksonJmsMessageConverter() {
		MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
		converter.setTargetType(MessageType.TEXT);
		converter.setTypeIdPropertyName("_type");
		return converter;
	}
}
