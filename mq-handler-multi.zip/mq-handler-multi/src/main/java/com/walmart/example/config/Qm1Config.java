package com.walmart.example.config;

import java.util.List;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.mq.spring.boot.MQConfigurationProperties;
import com.ibm.mq.spring.boot.MQConnectionFactoryCustomizer;
import com.ibm.msg.client.wmq.WMQConstants;

//import com.ibm.mq.spring.boot.MQConnectionFactoryFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

@Configuration
public class Qm1Config {

	private Environment environment;

	public Qm1Config(Environment environment) {
		this.environment = environment;
	}

	/*@Bean
	@ConfigurationProperties("qm1")
	public MQConfigurationProperties qm1ConfigProperties() {
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", Boolean.FALSE.toString());
		MQConfigurationProperties config = new MQConfigurationProperties();
		//getting from properties files
		// config.setQueueManager(environment.getProperty("ibm.mq.queueManager"));
		// config.setChannel(environment.getProperty("ibm.mq.channel"));
		// config.setConnName(environment.getProperty("ibm.mq.connName"));
		
		//not available on version mq 0.0.3 (Spring 1 support)
		//config.setSslFIPSRequired(Boolean.getBoolean(environment.getProperty("jms.sslFipsRequired")));
		config.setSslCipherSuite(environment.getProperty("jms.sslCipherSuite"));
		return config;
	}*/

	//not available on version mq 0.0.3 (Spring 1 support)
	/*@Bean
	public MQConnectionFactory qm1ConnectionFactory(
			@Qualifier("qm1ConfigProperties") MQConfigurationProperties properties,
			ObjectProvider<List<MQConnectionFactoryCustomizer>> factoryCustomizers) {
		return new MQConnectionFactoryFactory(properties, factoryCustomizers.getIfAvailable())
				.createConnectionFactory(MQConnectionFactory.class);
	}*/

	//@Primary required only on version mq 0.0.3 (Spring 1 support)
	@Primary
	@Bean
	public MQConnectionFactory qm1ConnectionFactory() throws JMSException {
		MQConnectionFactory connectionFactory = new MQConnectionFactory();
		connectionFactory.setHostName(environment.getProperty("qm3.host"));
		connectionFactory.setPort(Integer.valueOf(environment.getProperty("qm3.port")));
		connectionFactory.setQueueManager(environment.getProperty("qm3.queueManager"));
		connectionFactory.setChannel(environment.getProperty("qm3.channel"));
		connectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		connectionFactory.setBooleanProperty(WMQConstants.CAPABILITY_USERNAME_PASSWORD, true);
        connectionFactory.setStringProperty(WMQConstants.USERID, "admin");
        connectionFactory.setStringProperty(WMQConstants.PASSWORD, "passw0rd");  
		
		connectionFactory.setSSLFipsRequired(Boolean.getBoolean(environment.getProperty("jms.sslFipsRequired")));
		connectionFactory.setSSLCipherSuite(environment.getProperty("jms.sslCipherSuite"));
		System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", Boolean.FALSE.toString());
		return connectionFactory;
	}
	
	@Bean
	public JmsListenerContainerFactory<?> qm1JmsListenerContainerFactory(
			@Qualifier("qm1ConnectionFactory") ConnectionFactory connectionFactory,
			DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		configurer.configure(factory, connectionFactory);
		return factory;
	}

}